@1.1.0
* **Fixed:** When used with Bootstrap, CSS fade animation class name was conflicting with some of Bootstrap class names. 

(Reported by Hasim Yerli - https://github.com/hasimyerli)

----- 

@1.2.0
* **Changed:** JavaScript event listener improvements.

----- 

@1.3.0
* **Added:** The "**plainText**" options added to "**Notiflix Notify**" and "**Notiflix Confirm**" modules.  

(The "**plainText**" options can be set as "**false**" to use HTML allowed contents. Default values are "**true**" and not allowed HTML)

----- 